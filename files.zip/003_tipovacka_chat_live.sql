-- ============================================================
-- TIPOVACKA MS 2026 – Migrace 003: Chat + Live data
-- ============================================================
-- Spustit ПІСЛЯ 001 a 002.
-- ============================================================


-- ============================================================
-- SEKCE 1: ROZŠÍŘENÍ TABULKY MATCHES O LIVE DATA
-- ============================================================

ALTER TABLE matches
  ADD COLUMN IF NOT EXISTS api_fixture_id   INT UNIQUE,        -- ID z API-Football
  ADD COLUMN IF NOT EXISTS live_status      TEXT DEFAULT 'NS', -- NS/1H/HT/2H/FT/AET/PEN/PST
  ADD COLUMN IF NOT EXISTS live_minute      INT  DEFAULT 0,
  ADD COLUMN IF NOT EXISTS live_home        INT  DEFAULT 0,
  ADD COLUMN IF NOT EXISTS live_away        INT  DEFAULT 0,
  ADD COLUMN IF NOT EXISTS live_updated_at  TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_matches_api_fixture ON matches (api_fixture_id);
CREATE INDEX IF NOT EXISTS idx_matches_live_status ON matches (live_status);


-- ============================================================
-- SEKCE 2: LIVE UDÁLOSTI (góly, karty, střídání)
-- ============================================================

CREATE TABLE match_events (
  id             BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  match_id       BIGINT NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  api_event_id   INT,                                          -- interní ID z API (pro dedup)
  minute         INT,
  extra_minute   INT,                                          -- nastavený čas
  event_type     TEXT NOT NULL CHECK (event_type IN ('goal','card','subst','var','miss_penalty')),
  team_side      TEXT CHECK (team_side IN ('home','away')),
  player_name    TEXT,
  assist_name    TEXT,                                         -- u gólů asistence
  card_color     TEXT CHECK (card_color IN ('yellow','red','yellow_red')),
  detail         TEXT,                                         -- 'Normal Goal', 'Penalty', 'Own Goal'...
  created_at     TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (match_id, api_event_id)
);

CREATE INDEX idx_events_match ON match_events (match_id);


-- ============================================================
-- SEKCE 3: SOUPISKY (dostupné ~60 min před výkopem)
-- ============================================================

CREATE TABLE match_lineups (
  id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  match_id     BIGINT NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  team_side    TEXT NOT NULL CHECK (team_side IN ('home','away')),
  team_code    TEXT,                                           -- 'CZE', 'GER' atd.
  formation    TEXT,                                           -- '4-3-3'
  coach_name   TEXT,
  players      JSONB DEFAULT '[]',
  -- [{number, name, pos, grid, is_starter, photo_url}]
  updated_at   TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (match_id, team_side)
);

CREATE INDEX idx_lineups_match ON match_lineups (match_id);


-- ============================================================
-- SEKCE 4: CHAT ZPRÁVY
-- ============================================================
-- room_type = 'tournament' → turnajový chat (match_id NULL)
-- room_type = 'match'      → chat k zápasu (match_id povinný)

CREATE TABLE chat_messages (
  id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  room_type   TEXT NOT NULL CHECK (room_type IN ('tournament','match')),
  match_id    BIGINT REFERENCES matches(id) ON DELETE CASCADE,
  user_id     UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content     TEXT NOT NULL
                CHECK (LENGTH(TRIM(content)) >= 1 AND LENGTH(content) <= 500),
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  -- Konzistence: match chat musí mít match_id, turnajový ne
  CONSTRAINT chat_match_required
    CHECK (room_type = 'tournament' OR match_id IS NOT NULL)
);

CREATE INDEX idx_chat_tournament ON chat_messages (room_type, created_at DESC)
  WHERE room_type = 'tournament';
CREATE INDEX idx_chat_match ON chat_messages (match_id, created_at DESC)
  WHERE room_type = 'match';
CREATE INDEX idx_chat_user ON chat_messages (user_id);


-- ============================================================
-- SEKCE 5: RLS
-- ============================================================

-- match_events: čte každý přihlášený, admin/system zapisuje
ALTER TABLE match_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "events_select" ON match_events FOR SELECT TO authenticated USING (TRUE);
-- INSERT/UPDATE přes service_role (Edge Function) → žádná RLS policy pro anon/authenticated INSERT

-- match_lineups
ALTER TABLE match_lineups ENABLE ROW LEVEL SECURITY;
CREATE POLICY "lineups_select" ON match_lineups FOR SELECT TO authenticated USING (TRUE);

-- chat_messages
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "chat_select"
  ON chat_messages FOR SELECT TO authenticated USING (TRUE);

CREATE POLICY "chat_insert"
  ON chat_messages FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "chat_delete_own"
  ON chat_messages FOR DELETE TO authenticated
  USING (user_id = auth.uid() OR is_admin());


-- ============================================================
-- SEKCE 6: SUPABASE REALTIME
-- ============================================================
-- Zapnout Realtime pro chat a live data
-- (musí se povolit i v Supabase Dashboard → Database → Replication)

ALTER PUBLICATION supabase_realtime ADD TABLE chat_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE match_events;
ALTER PUBLICATION supabase_realtime ADD TABLE match_lineups;


-- ============================================================
-- SEKCE 7: GRANTY PRO SERVICE ROLE (Edge Functions)
-- ============================================================
-- Edge Function poběží jako service_role → obchází RLS → může INSERT/UPDATE

GRANT SELECT, INSERT, UPDATE ON match_events  TO service_role;
GRANT SELECT, INSERT, UPDATE ON match_lineups TO service_role;
GRANT SELECT, UPDATE         ON matches       TO service_role;


-- ============================================================
-- OVĚŘENÍ
-- ============================================================
-- SELECT column_name FROM information_schema.columns
--   WHERE table_name = 'matches' AND column_name LIKE 'live%';
-- → live_status, live_minute, live_home, live_away, live_updated_at, api_fixture_id
--
-- SELECT COUNT(*) FROM chat_messages;  → 0
-- SELECT COUNT(*) FROM match_events;   → 0
-- ============================================================
