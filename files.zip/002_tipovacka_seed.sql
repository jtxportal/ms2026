-- ============================================================
-- TIPOVACKA MS 2026 – Migrace 002: Seed teams + group matches
-- ============================================================
-- Spustit ПІСЛЯ 001_tipovacka_schema.sql.
-- Časy zápasů: UTC (EDT = UTC-4, vše přepočteno).
-- Zobrazení v aplikaci: Europe/Prague (CEST = UTC+2).
--
-- Nominace a přátelské zápasy: prázdné pole [].
-- Správce může doplnit v Supabase Table Editor nebo admin panelu.
-- ============================================================


-- ============================================================
-- SEKCE A: TÝMY (48 týmů, skupiny A–L)
-- ============================================================

INSERT INTO teams (id, nazev, skupina, vlajka_url, kvalifikace_postaveni, kvalifikace_vysledky, pratelske, nominace) VALUES

-- SKUPINA A
('MEX', 'Mexiko',           'A', 'https://flagcdn.com/mx.svg', 'Hostitel – automatická účast',   '[]', '[]', '[]'),
('RSA', 'Jihoafrická republika','A','https://flagcdn.com/za.svg','CAF – 2. místo skupiny E',      '[]', '[]', '[]'),
('KOR', 'Korea',            'A', 'https://flagcdn.com/kr.svg', 'AFC – 2. místo skupiny B',        '[]', '[]', '[]'),
('CZE', 'Česko',            'A', 'https://flagcdn.com/cz.svg', 'UEFA – 1. místo skupiny E',       '[]', '[]', '[]'),

-- SKUPINA B
('CAN', 'Kanada',           'B', 'https://flagcdn.com/ca.svg', 'Hostitel – automatická účast',   '[]', '[]', '[]'),
('BIH', 'Bosna a Hercegovina','B','https://flagcdn.com/ba.svg','UEFA – playoff (přes Finsko)',    '[]', '[]', '[]'),
('QAT', 'Katar',            'B', 'https://flagcdn.com/qa.svg', 'AFC – obhájce účasti (host 2022)','[]', '[]', '[]'),
('SUI', 'Švýcarsko',        'B', 'https://flagcdn.com/ch.svg', 'UEFA – 2. místo skupiny C',       '[]', '[]', '[]'),

-- SKUPINA C
('BRA', 'Brazílie',         'C', 'https://flagcdn.com/br.svg', 'CONMEBOL – 1. místo',            '[]', '[]', '[]'),
('MAR', 'Maroko',           'C', 'https://flagcdn.com/ma.svg', 'CAF – 1. místo skupiny C',        '[]', '[]', '[]'),
('HAI', 'Haiti',            'C', 'https://flagcdn.com/ht.svg', 'CONCACAF – 4. místo',             '[]', '[]', '[]'),
('SCO', 'Skotsko',          'C', 'https://flagcdn.com/gb-sct.svg','UEFA – 2. místo skupiny B',   '[]', '[]', '[]'),

-- SKUPINA D
('USA', 'USA',              'D', 'https://flagcdn.com/us.svg', 'Hostitel – automatická účast',   '[]', '[]', '[]'),
('PAR', 'Paraguay',         'D', 'https://flagcdn.com/py.svg', 'CONMEBOL – 5. místo',            '[]', '[]', '[]'),
('AUS', 'Austrálie',        'D', 'https://flagcdn.com/au.svg', 'AFC – 1. místo skupiny A',        '[]', '[]', '[]'),
('TUR', 'Türkiye',          'D', 'https://flagcdn.com/tr.svg', 'UEFA – playoff (přes Kosovo)',    '[]', '[]', '[]'),

-- SKUPINA E
('GER', 'Německo',          'E', 'https://flagcdn.com/de.svg', 'UEFA – 1. místo skupiny D',       '[]', '[]', '[]'),
('CUW', 'Curaçao',          'E', 'https://flagcdn.com/cw.svg', 'CONCACAF – 5. místo',             '[]', '[]', '[]'),
('CIV', 'Pobřeží slonoviny','E', 'https://flagcdn.com/ci.svg', 'CAF – 1. místo skupiny B',        '[]', '[]', '[]'),
('ECU', 'Ekvádor',          'E', 'https://flagcdn.com/ec.svg', 'CONMEBOL – 4. místo',             '[]', '[]', '[]'),

-- SKUPINA F
('NED', 'Nizozemsko',       'F', 'https://flagcdn.com/nl.svg', 'UEFA – 1. místo skupiny A',       '[]', '[]', '[]'),
('JPN', 'Japonsko',         'F', 'https://flagcdn.com/jp.svg', 'AFC – 1. místo skupiny C',        '[]', '[]', '[]'),
('SWE', 'Švédsko',          'F', 'https://flagcdn.com/se.svg', 'UEFA – 1. místo skupiny F',       '[]', '[]', '[]'),
('TUN', 'Tunisko',          'F', 'https://flagcdn.com/tn.svg', 'CAF – 1. místo skupiny D',        '[]', '[]', '[]'),

-- SKUPINA G
('BEL', 'Belgie',           'G', 'https://flagcdn.com/be.svg', 'UEFA – 1. místo skupiny G',       '[]', '[]', '[]'),
('EGY', 'Egypt',            'G', 'https://flagcdn.com/eg.svg', 'CAF – 1. místo skupiny F',        '[]', '[]', '[]'),
('IRN', 'Írán',             'G', 'https://flagcdn.com/ir.svg', 'AFC – 1. místo skupiny A',        '[]', '[]', '[]'),
('NZL', 'Nový Zéland',      'G', 'https://flagcdn.com/nz.svg', 'OFC – 1. místo (jediný zástupce)','[]', '[]', '[]'),

-- SKUPINA H
('ESP', 'Španělsko',        'H', 'https://flagcdn.com/es.svg', 'UEFA – 1. místo skupiny H',       '[]', '[]', '[]'),
('CPV', 'Kapverdy',         'H', 'https://flagcdn.com/cv.svg', 'CAF – 2. místo skupiny A',        '[]', '[]', '[]'),
('KSA', 'Saúdská Arábie',   'H', 'https://flagcdn.com/sa.svg', 'AFC – 2. místo skupiny C',        '[]', '[]', '[]'),
('URU', 'Uruguay',          'H', 'https://flagcdn.com/uy.svg', 'CONMEBOL – 3. místo',             '[]', '[]', '[]'),

-- SKUPINA I
('FRA', 'Francie',          'I', 'https://flagcdn.com/fr.svg', 'UEFA – 1. místo skupiny B',       '[]', '[]', '[]'),
('SEN', 'Senegal',          'I', 'https://flagcdn.com/sn.svg', 'CAF – 1. místo skupiny A',        '[]', '[]', '[]'),
('IRQ', 'Irák',             'I', 'https://flagcdn.com/iq.svg', 'AFC – 3. místo skupiny B',        '[]', '[]', '[]'),
('NOR', 'Norsko',           'I', 'https://flagcdn.com/no.svg', 'UEFA – 2. místo skupiny H',       '[]', '[]', '[]'),

-- SKUPINA J
('ARG', 'Argentina',        'J', 'https://flagcdn.com/ar.svg', 'CONMEBOL – 2. místo (obhájce)',   '[]', '[]', '[]'),
('ALG', 'Alžírsko',         'J', 'https://flagcdn.com/dz.svg', 'CAF – 1. místo skupiny H',        '[]', '[]', '[]'),
('AUT', 'Rakousko',         'J', 'https://flagcdn.com/at.svg', 'UEFA – 1. místo skupiny I',       '[]', '[]', '[]'),
('JOR', 'Jordánsko',        'J', 'https://flagcdn.com/jo.svg', 'AFC – 4. místo skupiny B',        '[]', '[]', '[]'),

-- SKUPINA K
('POR', 'Portugalsko',      'K', 'https://flagcdn.com/pt.svg', 'UEFA – 1. místo skupiny J',       '[]', '[]', '[]'),
('COD', 'DR Kongo',         'K', 'https://flagcdn.com/cd.svg', 'CAF – 2. místo skupiny G',        '[]', '[]', '[]'),
('UZB', 'Uzbekistán',       'K', 'https://flagcdn.com/uz.svg', 'AFC – 3. místo skupiny A',        '[]', '[]', '[]'),
('COL', 'Kolumbie',         'K', 'https://flagcdn.com/co.svg', 'CONMEBOL – 6. místo',             '[]', '[]', '[]'),

-- SKUPINA L
('ENG', 'Anglie',           'L', 'https://flagcdn.com/gb-eng.svg','UEFA – 1. místo skupiny C',    '[]', '[]', '[]'),
('CRO', 'Chorvatsko',       'L', 'https://flagcdn.com/hr.svg', 'UEFA – playoff (přes Island)',     '[]', '[]', '[]'),
('GHA', 'Ghana',            'L', 'https://flagcdn.com/gh.svg', 'CAF – 2. místo skupiny I',        '[]', '[]', '[]'),
('PAN', 'Panama',           'L', 'https://flagcdn.com/pa.svg', 'CONCACAF – 6. místo',             '[]', '[]', '[]');


-- ============================================================
-- SEKCE B: ZÁPASY SKUPINOVÉ FÁZE (72 zápasů)
-- ============================================================
-- Časy v UTC (EDT = UTC−4, CEST = UTC+2):
--   19:00 UTC = 21:00 CEST   (ideální česká večerní hodina)
--   02:00 UTC = 04:00 CEST   (noc – ranní hodiny v ČR)
--   17:00 UTC = 19:00 CEST
--   20:00 UTC = 22:00 CEST
-- ============================================================

INSERT INTO matches (faze, skupina, vykop, tym_domaci, tym_hosti) VALUES

-- ======================== SKUPINA A ========================
('skupina', 'A', '2026-06-11 19:00:00+00', 'MEX', 'RSA'),   -- čt 11.6. 21:00 CEST
('skupina', 'A', '2026-06-12 02:00:00+00', 'KOR', 'CZE'),   -- pá 12.6. 04:00 CEST ⚽ ČESKO
('skupina', 'A', '2026-06-18 16:00:00+00', 'CZE', 'RSA'),   -- čt 18.6. 18:00 CEST ⚽ ČESKO
('skupina', 'A', '2026-06-19 01:00:00+00', 'MEX', 'KOR'),   -- pá 19.6. 03:00 CEST
('skupina', 'A', '2026-06-25 01:00:00+00', 'CZE', 'MEX'),   -- čt 25.6. 03:00 CEST ⚽ ČESKO
('skupina', 'A', '2026-06-25 01:00:00+00', 'RSA', 'KOR'),   -- čt 25.6. 03:00 CEST

-- ======================== SKUPINA B ========================
('skupina', 'B', '2026-06-12 19:00:00+00', 'CAN', 'BIH'),   -- pá 12.6. 21:00 CEST
('skupina', 'B', '2026-06-13 19:00:00+00', 'QAT', 'SUI'),   -- so 13.6. 21:00 CEST
('skupina', 'B', '2026-06-18 19:00:00+00', 'SUI', 'BIH'),   -- čt 18.6. 21:00 CEST
('skupina', 'B', '2026-06-18 22:00:00+00', 'CAN', 'QAT'),   -- čt 18.6. 00:00 CEST (pá)
('skupina', 'B', '2026-06-24 19:00:00+00', 'SUI', 'CAN'),   -- st 24.6. 21:00 CEST
('skupina', 'B', '2026-06-24 19:00:00+00', 'BIH', 'QAT'),   -- st 24.6. 21:00 CEST

-- ======================== SKUPINA C ========================
('skupina', 'C', '2026-06-13 22:00:00+00', 'BRA', 'MAR'),   -- so 13.6. 00:00 CEST (ne)
('skupina', 'C', '2026-06-14 01:00:00+00', 'HAI', 'SCO'),   -- ne 14.6. 03:00 CEST
('skupina', 'C', '2026-06-19 22:00:00+00', 'SCO', 'MAR'),   -- pá 19.6. 00:00 CEST (so)
('skupina', 'C', '2026-06-20 00:30:00+00', 'BRA', 'HAI'),   -- so 20.6. 02:30 CEST
('skupina', 'C', '2026-06-24 22:00:00+00', 'SCO', 'BRA'),   -- st 24.6. 00:00 CEST (čt)
('skupina', 'C', '2026-06-24 22:00:00+00', 'MAR', 'HAI'),   -- st 24.6. 00:00 CEST (čt)

-- ======================== SKUPINA D ========================
('skupina', 'D', '2026-06-13 01:00:00+00', 'USA', 'PAR'),   -- so 13.6. 03:00 CEST
('skupina', 'D', '2026-06-13 04:00:00+00', 'AUS', 'TUR'),   -- so 13.6. 06:00 CEST
('skupina', 'D', '2026-06-19 19:00:00+00', 'USA', 'AUS'),   -- pá 19.6. 21:00 CEST
('skupina', 'D', '2026-06-20 03:00:00+00', 'TUR', 'PAR'),   -- so 20.6. 05:00 CEST
('skupina', 'D', '2026-06-26 02:00:00+00', 'TUR', 'USA'),   -- čt 26.6. 04:00 CEST
('skupina', 'D', '2026-06-26 02:00:00+00', 'PAR', 'AUS'),   -- čt 26.6. 04:00 CEST

-- ======================== SKUPINA E ========================
('skupina', 'E', '2026-06-14 17:00:00+00', 'GER', 'CUW'),   -- ne 14.6. 19:00 CEST
('skupina', 'E', '2026-06-14 23:00:00+00', 'CIV', 'ECU'),   -- ne 14.6. 01:00 CEST (po)
('skupina', 'E', '2026-06-20 20:00:00+00', 'GER', 'CIV'),   -- so 20.6. 22:00 CEST
('skupina', 'E', '2026-06-21 00:00:00+00', 'ECU', 'CUW'),   -- ne 21.6. 02:00 CEST
('skupina', 'E', '2026-06-25 20:00:00+00', 'CUW', 'CIV'),   -- čt 25.6. 22:00 CEST
('skupina', 'E', '2026-06-25 20:00:00+00', 'ECU', 'GER'),   -- čt 25.6. 22:00 CEST

-- ======================== SKUPINA F ========================
('skupina', 'F', '2026-06-14 20:00:00+00', 'NED', 'JPN'),   -- ne 14.6. 22:00 CEST
('skupina', 'F', '2026-06-15 02:00:00+00', 'SWE', 'TUN'),   -- po 15.6. 04:00 CEST
('skupina', 'F', '2026-06-20 04:00:00+00', 'TUN', 'JPN'),   -- so 20.6. 06:00 CEST
('skupina', 'F', '2026-06-20 17:00:00+00', 'NED', 'SWE'),   -- so 20.6. 19:00 CEST
('skupina', 'F', '2026-06-25 23:00:00+00', 'JPN', 'SWE'),   -- čt 25.6. 01:00 CEST (pá)
('skupina', 'F', '2026-06-25 23:00:00+00', 'TUN', 'NED'),   -- čt 25.6. 01:00 CEST (pá)

-- ======================== SKUPINA G ========================
('skupina', 'G', '2026-06-15 19:00:00+00', 'BEL', 'EGY'),   -- po 15.6. 21:00 CEST
('skupina', 'G', '2026-06-16 01:00:00+00', 'IRN', 'NZL'),   -- út 16.6. 03:00 CEST
('skupina', 'G', '2026-06-21 19:00:00+00', 'BEL', 'IRN'),   -- ne 21.6. 21:00 CEST
('skupina', 'G', '2026-06-22 01:00:00+00', 'NZL', 'EGY'),   -- po 22.6. 03:00 CEST
('skupina', 'G', '2026-06-27 03:00:00+00', 'EGY', 'IRN'),   -- so 27.6. 05:00 CEST
('skupina', 'G', '2026-06-27 03:00:00+00', 'NZL', 'BEL'),   -- so 27.6. 05:00 CEST

-- ======================== SKUPINA H ========================
('skupina', 'H', '2026-06-15 16:00:00+00', 'ESP', 'CPV'),   -- po 15.6. 18:00 CEST
('skupina', 'H', '2026-06-15 22:00:00+00', 'KSA', 'URU'),   -- po 15.6. 00:00 CEST (út)
('skupina', 'H', '2026-06-21 16:00:00+00', 'ESP', 'KSA'),   -- ne 21.6. 18:00 CEST
('skupina', 'H', '2026-06-21 22:00:00+00', 'URU', 'CPV'),   -- ne 21.6. 00:00 CEST (po)
('skupina', 'H', '2026-06-27 00:00:00+00', 'CPV', 'KSA'),   -- so 27.6. 02:00 CEST
('skupina', 'H', '2026-06-27 00:00:00+00', 'URU', 'ESP'),   -- so 27.6. 02:00 CEST

-- ======================== SKUPINA I ========================
('skupina', 'I', '2026-06-16 19:00:00+00', 'FRA', 'SEN'),   -- út 16.6. 21:00 CEST
('skupina', 'I', '2026-06-16 22:00:00+00', 'IRQ', 'NOR'),   -- út 16.6. 00:00 CEST (st)
('skupina', 'I', '2026-06-22 21:00:00+00', 'FRA', 'IRQ'),   -- po 22.6. 23:00 CEST
('skupina', 'I', '2026-06-23 00:00:00+00', 'NOR', 'SEN'),   -- út 23.6. 02:00 CEST
('skupina', 'I', '2026-06-26 19:00:00+00', 'NOR', 'FRA'),   -- pá 26.6. 21:00 CEST
('skupina', 'I', '2026-06-26 19:00:00+00', 'SEN', 'IRQ'),   -- pá 26.6. 21:00 CEST

-- ======================== SKUPINA J ========================
('skupina', 'J', '2026-06-17 01:00:00+00', 'ARG', 'ALG'),   -- st 17.6. 03:00 CEST
('skupina', 'J', '2026-06-17 04:00:00+00', 'AUT', 'JOR'),   -- st 17.6. 06:00 CEST
('skupina', 'J', '2026-06-22 17:00:00+00', 'ARG', 'AUT'),   -- po 22.6. 19:00 CEST
('skupina', 'J', '2026-06-23 03:00:00+00', 'JOR', 'ALG'),   -- út 23.6. 05:00 CEST
('skupina', 'J', '2026-06-28 02:00:00+00', 'JOR', 'ARG'),   -- ne 28.6. 04:00 CEST
('skupina', 'J', '2026-06-28 02:00:00+00', 'ALG', 'AUT'),   -- ne 28.6. 04:00 CEST

-- ======================== SKUPINA K ========================
('skupina', 'K', '2026-06-17 17:00:00+00', 'POR', 'COD'),   -- st 17.6. 19:00 CEST
('skupina', 'K', '2026-06-18 02:00:00+00', 'UZB', 'COL'),   -- čt 18.6. 04:00 CEST
('skupina', 'K', '2026-06-23 17:00:00+00', 'POR', 'UZB'),   -- út 23.6. 19:00 CEST
('skupina', 'K', '2026-06-24 02:00:00+00', 'COL', 'COD'),   -- st 24.6. 04:00 CEST
('skupina', 'K', '2026-06-27 23:30:00+00', 'COL', 'POR'),   -- so 28.6. 01:30 CEST
('skupina', 'K', '2026-06-27 23:30:00+00', 'COD', 'UZB'),   -- so 28.6. 01:30 CEST

-- ======================== SKUPINA L ========================
('skupina', 'L', '2026-06-17 20:00:00+00', 'ENG', 'CRO'),   -- st 17.6. 22:00 CEST
('skupina', 'L', '2026-06-17 23:00:00+00', 'GHA', 'PAN'),   -- čt 18.6. 01:00 CEST
('skupina', 'L', '2026-06-23 20:00:00+00', 'ENG', 'GHA'),   -- út 23.6. 22:00 CEST
('skupina', 'L', '2026-06-23 23:00:00+00', 'PAN', 'CRO'),   -- st 24.6. 01:00 CEST
('skupina', 'L', '2026-06-27 21:00:00+00', 'PAN', 'ENG'),   -- so 27.6. 23:00 CEST
('skupina', 'L', '2026-06-27 21:00:00+00', 'CRO', 'GHA');   -- so 27.6. 23:00 CEST


-- ============================================================
-- SEKCE C: OVĚŘENÍ (spustit jako rychlý test po importu)
-- ============================================================
-- SELECT COUNT(*) FROM teams;    → 48
-- SELECT COUNT(*) FROM matches;  → 72
-- SELECT * FROM matches WHERE tym_domaci = 'CZE' OR tym_hosti = 'CZE';  → 3 zápasy


-- ============================================================
-- SEKCE D: NÁVOD PRO DOPLNĚNÍ DETAILŮ TÝMŮ
-- ============================================================
-- Nominace (příklad pro Česko):
-- UPDATE teams SET nominace = '[
--   {"jmeno": "Jindřich Staněk", "pozice": "GK", "klub": "Slavia Praha"},
--   {"jmeno": "Tomáš Souček",    "pozice": "MF", "klub": "West Ham United"},
--   ...
-- ]' WHERE id = 'CZE';
--
-- Přátelské zápasy:
-- UPDATE teams SET pratelske = '[
--   {"datum": "2026-06-06", "soupere": "Česko", "vysledek": "2-1", "hoster": "Česko"},
--   ...
-- ]' WHERE id = 'GER';
--
-- Admin panel v aplikaci toto umožní graficky.
-- ============================================================

-- ============================================================
-- HOTOVO – skupina (A–L) + 72 zápasů naloadováno
-- Další krok: spustit React aplikaci a propojit se Supabase
-- ============================================================
