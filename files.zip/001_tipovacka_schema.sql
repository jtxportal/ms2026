-- ============================================================
-- TIPOVACKA MS 2026 – Migrace 001: Schéma + Funkce + RLS
-- ============================================================
-- Spustit celý soubor najednou v Supabase SQL Editoru.
--
-- MS 2026 má 48 týmů → nový Round of 32 = sestnactifinale
-- Ceník: skupina 10 | sestnactifinale/osmifinale/ctvrtfinale 20
--        semifinale/o_3_misto 50 | finale 100
-- ============================================================


-- ============================================================
-- SEKCE 1: ENUM
-- ============================================================

CREATE TYPE faze_type AS ENUM (
  'skupina',
  'sestnactifinale',   -- Round of 32: 48 → 32 týmů (16 zápasů)
  'osmifinale',        -- Round of 16: 32 → 16 týmů  ( 8 zápasů)
  'ctvrtfinale',       -- QF: 8 → 4 týmy              ( 4 zápasy)
  'semifinale',        -- SF: 4 → 2 týmy              ( 2 zápasy)
  'o_3_misto',
  'finale'
);


-- ============================================================
-- SEKCE 2: TABULKY (v pořadí závislostí)
-- ============================================================

-- Profily (1:1 s auth.users)
CREATE TABLE profiles (
  id          UUID        PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  jmeno       TEXT        NOT NULL,
  prijmeni    TEXT        NOT NULL,
  prezdivka   TEXT        UNIQUE NOT NULL,
  telefon     TEXT,
  je_admin    BOOLEAN     NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Týmy – statický seed
CREATE TABLE teams (
  id                     TEXT  PRIMARY KEY,          -- 'CZE', 'BRA' …
  nazev                  TEXT  NOT NULL,
  skupina                CHAR(1),
  vlajka_url             TEXT,
  kvalifikace_postaveni  TEXT,
  kvalifikace_vysledky   JSONB DEFAULT '[]',          -- [{datum,soupere,vysledek,misto}]
  pratelske              JSONB DEFAULT '[]',           -- [{datum,soupere,vysledek}]
  nominace               JSONB DEFAULT '[]'            -- [{jmeno,pozice,klub,vek}]
);

-- Zápasy (UTC časy, zobrazovat v Europe/Prague)
CREATE TABLE matches (
  id               BIGINT      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  faze             faze_type   NOT NULL,
  skupina          CHAR(1),                            -- pouze skupinová fáze
  vykop            TIMESTAMPTZ NOT NULL,               -- UTC!
  tym_domaci       TEXT        REFERENCES teams(id),   -- NULL u TBD play-off
  tym_hosti        TEXT        REFERENCES teams(id),
  vysledek_domaci  INT         CHECK (vysledek_domaci >= 0),
  vysledek_hosti   INT         CHECK (vysledek_hosti  >= 0),
  vyhodnoceno      BOOLEAN     NOT NULL DEFAULT FALSE,
  created_at       TIMESTAMPTZ DEFAULT NOW()
);

-- Tipy na zápasy
CREATE TABLE bets (
  id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  match_id     BIGINT NOT NULL REFERENCES matches(id) ON DELETE RESTRICT,
  user_id      UUID   NOT NULL REFERENCES profiles(id) ON DELETE RESTRICT,
  tip_domaci   INT    NOT NULL CHECK (tip_domaci >= 0),
  tip_hosti    INT    NOT NULL CHECK (tip_hosti  >= 0),
  castka       INT    NOT NULL,                        -- auto-vyplní trigger
  vyhra        INT    NOT NULL DEFAULT 0,
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (match_id, user_id)                           -- 1 tip / zápas / hráč
);

-- Dlouhodobé tipy (vítěz turnaje, nejlepší střelec)
CREATE TABLE longterm_bets (
  id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id    UUID   NOT NULL REFERENCES profiles(id) ON DELETE RESTRICT,
  typ        TEXT   NOT NULL CHECK (typ IN ('vitez', 'strelec')),
  hodnota    TEXT   NOT NULL,
  castka     INT    NOT NULL DEFAULT 10,
  vyhra      INT    NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (user_id, typ)                                -- 1 tip / kategorie / hráč
);

-- Jackpot – jeden řádek (id vždy = 1)
CREATE TABLE jackpot (
  id        INT PRIMARY KEY DEFAULT 1,
  zustatek  INT NOT NULL DEFAULT 0,
  CHECK (id = 1)
);

-- Výplaty z finálního jackpotu po skončení turnaje
CREATE TABLE jackpot_payouts (
  id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id    UUID NOT NULL REFERENCES profiles(id),
  castka     INT  NOT NULL,
  duvod      TEXT DEFAULT 'jackpot_final',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Stav turnaje – jeden řádek (id vždy = 1)
CREATE TABLE tournament_state (
  id                INT     PRIMARY KEY DEFAULT 1,
  vitez_ms          TEXT,                              -- admin vyplní po finále
  nejlepsi_strelec  TEXT,
  ukonceno          BOOLEAN NOT NULL DEFAULT FALSE,
  CHECK (id = 1)
);

-- Počáteční singleton řádky
INSERT INTO jackpot          (id, zustatek) VALUES (1, 0);
INSERT INTO tournament_state (id)           VALUES (1);


-- ============================================================
-- SEKCE 3: INDEXY
-- ============================================================

CREATE INDEX idx_bets_match   ON bets         (match_id);
CREATE INDEX idx_bets_user    ON bets         (user_id);
CREATE INDEX idx_matches_vykop ON matches     (vykop);
CREATE INDEX idx_matches_faze  ON matches     (faze);
CREATE INDEX idx_lt_user       ON longterm_bets (user_id);
CREATE INDEX idx_jp_user       ON jackpot_payouts (user_id);


-- ============================================================
-- SEKCE 4: HELPER FUNKCE
-- ============================================================

-- Cena tipu dle fáze turnaje
CREATE OR REPLACE FUNCTION get_tip_price(p_faze faze_type)
RETURNS INT LANGUAGE sql IMMUTABLE AS $$
  SELECT CASE p_faze
    WHEN 'skupina'          THEN 10
    WHEN 'sestnactifinale'  THEN 20
    WHEN 'osmifinale'       THEN 20
    WHEN 'ctvrtfinale'      THEN 20
    WHEN 'semifinale'       THEN 50
    WHEN 'o_3_misto'        THEN 50
    WHEN 'finale'           THEN 100
    ELSE 10
  END;
$$;

-- Je aktuální uživatel admin?
-- SECURITY DEFINER: bezpečně čte profiles bez RLS smyčky
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN LANGUAGE sql SECURITY DEFINER STABLE AS $$
  SELECT COALESCE(
    (SELECT je_admin FROM profiles WHERE id = auth.uid()),
    FALSE
  );
$$;


-- ============================================================
-- SEKCE 5: TRIGGER – auto-vyplnění castka při podání tipu
-- ============================================================

CREATE OR REPLACE FUNCTION bets_set_castka()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.castka := get_tip_price(
    (SELECT faze FROM matches WHERE id = NEW.match_id)
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_bets_castka
  BEFORE INSERT ON bets
  FOR EACH ROW EXECUTE FUNCTION bets_set_castka();


-- ============================================================
-- SEKCE 6: ŽEBŘÍČEK – SECURITY DEFINER funkce
-- ============================================================
-- DŮLEŽITÉ: Nelze použít VIEW – Supabase RLS na tabulce bets
-- by každému zobrazilo pouze vlastní tipy a žebříček by byl rozbitý.
-- SECURITY DEFINER funkce obchází RLS jen pro agregáty, nikoliv
-- pro výpis individuálních tipů (ty jsou nadále chráněny).

CREATE OR REPLACE FUNCTION get_player_standings()
RETURNS TABLE (
  id              UUID,
  prezdivka       TEXT,
  pocet_tipu      BIGINT,
  vsazeno_celkem  BIGINT,
  vyhrano_celkem  BIGINT,
  zisk            BIGINT,
  poradi          BIGINT
)
LANGUAGE sql SECURITY DEFINER STABLE AS $$
  WITH b AS (
    SELECT user_id,
           SUM(castka) AS vsazeno,
           SUM(vyhra)  AS vyhrano,
           COUNT(*)    AS pocet_tipu
    FROM bets
    GROUP BY user_id
  ),
  lt AS (
    SELECT user_id,
           SUM(castka) AS vsazeno,
           SUM(vyhra)  AS vyhrano
    FROM longterm_bets
    GROUP BY user_id
  ),
  jp AS (
    SELECT user_id, SUM(castka) AS vyhrano
    FROM jackpot_payouts
    GROUP BY user_id
  ),
  saldo AS (
    SELECT
      p.id,
      p.prezdivka,
      COALESCE(b.pocet_tipu, 0)                                               AS pocet_tipu,
      COALESCE(b.vsazeno,   0) + COALESCE(lt.vsazeno, 0)                      AS vsazeno_celkem,
      COALESCE(b.vyhrano,   0) + COALESCE(lt.vyhrano, 0) + COALESCE(jp.vyhrano, 0) AS vyhrano_celkem,
      (COALESCE(b.vyhrano,  0) + COALESCE(lt.vyhrano, 0) + COALESCE(jp.vyhrano, 0))
      - (COALESCE(b.vsazeno, 0) + COALESCE(lt.vsazeno, 0))                   AS zisk
    FROM profiles p
    LEFT JOIN b  ON b.user_id  = p.id
    LEFT JOIN lt ON lt.user_id = p.id
    LEFT JOIN jp ON jp.user_id = p.id
  )
  SELECT
    id, prezdivka, pocet_tipu, vsazeno_celkem, vyhrano_celkem, zisk,
    DENSE_RANK() OVER (ORDER BY zisk DESC) AS poradi
  FROM saldo;
$$;

-- Statistiky zápasu (agregáty) – SECURITY DEFINER, vrací jen počty, ne tipy
CREATE OR REPLACE FUNCTION get_match_stats(p_match_id BIGINT)
RETURNS TABLE (pocet_tipu INT, bank INT, pocet_vitezou INT)
LANGUAGE sql SECURITY DEFINER STABLE AS $$
  SELECT
    COUNT(*)::INT,
    (COUNT(*) * get_tip_price((SELECT faze FROM matches WHERE id = p_match_id)))::INT,
    SUM(CASE WHEN vyhra > 0 THEN 1 ELSE 0 END)::INT
  FROM bets
  WHERE match_id = p_match_id;
$$;


-- ============================================================
-- SEKCE 7: FUNKCE – VYHODNOCENÍ ZÁPASU (settle_match)
-- ============================================================
-- Volá admin přes supabase.rpc('settle_match', { p_match_id: 42 })
-- Atomicky: spočítá bank, najde výherce, rozdělí bank+jackpot,
-- nebo přičte bank do jackpotu (nikdo netrefil).

CREATE OR REPLACE FUNCTION settle_match(p_match_id BIGINT)
RETURNS JSONB LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  v_match          matches%ROWTYPE;
  v_bank           INT;
  v_jackpot_pred   INT;
  v_vitezove       BIGINT[];
  v_pocet          INT;
  v_vyplata        INT;
  v_na_osobu       INT;
  v_zbytek         INT;
  v_jackpot_po     INT;
BEGIN
  -- Ochrana: jen admin
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Pouze admin může vyhodnocovat zápasy.';
  END IF;

  -- Uzamknout zápas pro transakci
  SELECT * INTO v_match FROM matches WHERE id = p_match_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Zápas % neexistuje.', p_match_id;
  END IF;
  IF v_match.vyhodnoceno THEN
    RAISE EXCEPTION 'Zápas % je již vyhodnocen.', p_match_id;
  END IF;
  IF v_match.vysledek_domaci IS NULL OR v_match.vysledek_hosti IS NULL THEN
    RAISE EXCEPTION 'Nejprve zadej výsledek zápasu %.', p_match_id;
  END IF;

  -- Bank zápasu
  SELECT (COUNT(*) * get_tip_price(v_match.faze))::INT
  INTO v_bank
  FROM bets WHERE match_id = p_match_id;

  -- Uzamknout jackpot
  SELECT zustatek INTO v_jackpot_pred FROM jackpot WHERE id = 1 FOR UPDATE;

  -- Najít vítěze (přesné skóre)
  SELECT ARRAY_AGG(id) INTO v_vitezove
  FROM bets
  WHERE match_id   = p_match_id
    AND tip_domaci = v_match.vysledek_domaci
    AND tip_hosti  = v_match.vysledek_hosti;

  v_pocet := COALESCE(ARRAY_LENGTH(v_vitezove, 1), 0);

  IF v_pocet > 0 THEN
    -- ✅ Někdo trefil → rozdělit bank + celý jackpot
    v_vyplata  := v_bank + v_jackpot_pred;
    v_na_osobu := v_vyplata / v_pocet;
    v_zbytek   := v_vyplata - (v_na_osobu * v_pocet);  -- haléřový zbytek → jackpot

    UPDATE bets SET vyhra = v_na_osobu WHERE id = ANY(v_vitezove);
    UPDATE jackpot SET zustatek = v_zbytek WHERE id = 1;
    v_jackpot_po := v_zbytek;
  ELSE
    -- ❌ Nikdo netrefil → bank přiteče do jackpotu (roste dál)
    UPDATE jackpot SET zustatek = v_jackpot_pred + v_bank WHERE id = 1;
    v_jackpot_po := v_jackpot_pred + v_bank;
  END IF;

  -- Označit zápas za vyhodnocený
  UPDATE matches SET vyhodnoceno = TRUE WHERE id = p_match_id;

  RETURN jsonb_build_object(
    'match_id',     p_match_id,
    'bank',         v_bank,
    'jackpot_pred', v_jackpot_pred,
    'vitezove',     v_pocet,
    'na_osobu',     CASE WHEN v_pocet > 0 THEN v_na_osobu ELSE 0 END,
    'jackpot_po',   v_jackpot_po
  );
END;
$$;


-- ============================================================
-- SEKCE 8: FUNKCE – VYHODNOCENÍ DLOUHODOBÝCH TIPŮ (settle_longterm)
-- ============================================================
-- Admin zavolá po nastavení vitez_ms a nejlepsi_strelec
-- v tournament_state a ukonceno = true.

CREATE OR REPLACE FUNCTION settle_longterm()
RETURNS JSONB LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  v_ts        tournament_state%ROWTYPE;
  v_typ       TEXT;
  v_hodnota   TEXT;
  v_bank      INT;
  v_vitezove  BIGINT[];
  v_pocet     INT;
  v_na_osobu  INT;
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Pouze admin může vyhodnocovat dlouhodobé tipy.';
  END IF;

  SELECT * INTO v_ts FROM tournament_state WHERE id = 1;

  IF NOT v_ts.ukonceno THEN
    RAISE EXCEPTION 'Nastav tournament_state.ukonceno = true před vyhodnocením.';
  END IF;
  IF v_ts.vitez_ms IS NULL THEN
    RAISE EXCEPTION 'Zadej vitez_ms v tournament_state.';
  END IF;
  IF v_ts.nejlepsi_strelec IS NULL THEN
    RAISE EXCEPTION 'Zadej nejlepsi_strelec v tournament_state.';
  END IF;

  FOREACH v_typ IN ARRAY ARRAY['vitez', 'strelec']::TEXT[] LOOP
    v_hodnota := CASE v_typ
      WHEN 'vitez'   THEN v_ts.vitez_ms
      WHEN 'strelec' THEN v_ts.nejlepsi_strelec
    END;

    SELECT COALESCE(SUM(castka), 0) INTO v_bank
    FROM longterm_bets WHERE typ = v_typ;

    SELECT ARRAY_AGG(id) INTO v_vitezove
    FROM longterm_bets
    WHERE typ = v_typ
      AND LOWER(TRIM(hodnota)) = LOWER(TRIM(v_hodnota));

    v_pocet := COALESCE(ARRAY_LENGTH(v_vitezove, 1), 0);

    IF v_pocet > 0 AND v_bank > 0 THEN
      v_na_osobu := v_bank / v_pocet;
      UPDATE longterm_bets SET vyhra = v_na_osobu WHERE id = ANY(v_vitezove);
    ELSIF v_bank > 0 THEN
      -- Nikdo netrefil → do jackpotu
      UPDATE jackpot SET zustatek = zustatek + v_bank WHERE id = 1;
    END IF;
  END LOOP;

  RETURN jsonb_build_object(
    'done',     true,
    'vitez_ms', v_ts.vitez_ms,
    'strelec',  v_ts.nejlepsi_strelec
  );
END;
$$;


-- ============================================================
-- SEKCE 9: FUNKCE – FINÁLNÍ ROZDĚLENÍ JACKPOTU (50 / 33 / 17 %)
-- ============================================================
-- Volá admin POSLEDNĚ, po settle_longterm.
-- Pořadí podle get_player_standings() (zisk = vyhráno − vsazeno).
-- Při méně než 3 obsazených místech zůstatek podílu zůstane
-- v jackpotu pro ruční řešení.

CREATE OR REPLACE FUNCTION distribute_final_jackpot()
RETURNS JSONB LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  v_jackpot       INT;
  v_p1 INT; v_p2 INT; v_p3 INT;
  v_r1 UUID[]; v_r2 UUID[]; v_r3 UUID[];
  v_c1 INT;    v_c2 INT;    v_c3 INT;
  v_not_dist      INT;
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Pouze admin může rozdělit finální jackpot.';
  END IF;

  SELECT zustatek INTO v_jackpot FROM jackpot WHERE id = 1 FOR UPDATE;

  IF v_jackpot <= 0 THEN
    RETURN jsonb_build_object('info', 'Jackpot je prázdný – není co rozdělovat.');
  END IF;

  -- Načíst top 3 pořadí z žebříčku
  SELECT
    ARRAY_AGG(id) FILTER (WHERE poradi = 1),
    ARRAY_AGG(id) FILTER (WHERE poradi = 2),
    ARRAY_AGG(id) FILTER (WHERE poradi = 3)
  INTO v_r1, v_r2, v_r3
  FROM get_player_standings()
  WHERE poradi <= 3;

  v_c1 := COALESCE(ARRAY_LENGTH(v_r1, 1), 0);
  v_c2 := COALESCE(ARRAY_LENGTH(v_r2, 1), 0);
  v_c3 := COALESCE(ARRAY_LENGTH(v_r3, 1), 0);

  -- Podíly (v_p3 = zbytek, aby se nic neztrácelo zaokrouhlením)
  v_p1 := (v_jackpot * 50) / 100;
  v_p2 := (v_jackpot * 33) / 100;
  v_p3 := v_jackpot - v_p1 - v_p2;

  -- Výplaty (rovným dílem při shodě)
  IF v_c1 > 0 THEN
    INSERT INTO jackpot_payouts (user_id, castka, duvod)
    SELECT unnest(v_r1), v_p1 / v_c1, '1_misto_50pct';
  END IF;

  IF v_c2 > 0 THEN
    INSERT INTO jackpot_payouts (user_id, castka, duvod)
    SELECT unnest(v_r2), v_p2 / v_c2, '2_misto_33pct';
  END IF;

  IF v_c3 > 0 THEN
    INSERT INTO jackpot_payouts (user_id, castka, duvod)
    SELECT unnest(v_r3), v_p3 / v_c3, '3_misto_17pct';
  END IF;

  -- Cokoliv nebylo rozděleno (prázdná místa nebo haléřové zbytky) zůstane v jackpotu
  v_not_dist :=
    CASE WHEN v_c1 = 0 THEN v_p1 ELSE 0 END +
    CASE WHEN v_c2 = 0 THEN v_p2 ELSE 0 END +
    CASE WHEN v_c3 = 0 THEN v_p3 ELSE 0 END;

  UPDATE jackpot SET zustatek = v_not_dist WHERE id = 1;

  RETURN jsonb_build_object(
    'jackpot_celkem', v_jackpot,
    'podil_1', v_p1, 'hracu_1', v_c1,
    'podil_2', v_p2, 'hracu_2', v_c2,
    'podil_3', v_p3, 'hracu_3', v_c3,
    'nedistribuovano', v_not_dist
  );
END;
$$;


-- ============================================================
-- SEKCE 10: ROW LEVEL SECURITY
-- ============================================================

-- profiles -----------------------------------------------
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "profiles_select"
  ON profiles FOR SELECT TO authenticated USING (TRUE);

CREATE POLICY "profiles_insert"
  ON profiles FOR INSERT TO authenticated
  WITH CHECK (id = auth.uid());

CREATE POLICY "profiles_update"
  ON profiles FOR UPDATE TO authenticated
  USING    (id = auth.uid() OR is_admin())
  WITH CHECK (id = auth.uid() OR is_admin());

CREATE POLICY "profiles_delete"
  ON profiles FOR DELETE TO authenticated
  USING (is_admin());

-- teams --------------------------------------------------
ALTER TABLE teams ENABLE ROW LEVEL SECURITY;

CREATE POLICY "teams_select"
  ON teams FOR SELECT TO authenticated USING (TRUE);

CREATE POLICY "teams_write"
  ON teams FOR ALL TO authenticated
  USING (is_admin()) WITH CHECK (is_admin());

-- matches ------------------------------------------------
ALTER TABLE matches ENABLE ROW LEVEL SECURITY;

CREATE POLICY "matches_select"
  ON matches FOR SELECT TO authenticated USING (TRUE);

CREATE POLICY "matches_write"
  ON matches FOR ALL TO authenticated
  USING (is_admin()) WITH CHECK (is_admin());

-- bets ---------------------------------------------------
-- SELECT: jen vlastní tipy (nebo admin vidí vše)
-- INSERT: před výkopem, zápas nesmí být vyhodnocen
-- UPDATE: jen svůj tip, jen před výkopem
ALTER TABLE bets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "bets_select"
  ON bets FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR is_admin());

CREATE POLICY "bets_insert"
  ON bets FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND (SELECT vykop       FROM matches WHERE id = match_id) > NOW()
    AND NOT (SELECT vyhodnoceno FROM matches WHERE id = match_id)
  );

CREATE POLICY "bets_update"
  ON bets FOR UPDATE TO authenticated
  USING (
    user_id = auth.uid()
    AND (SELECT vykop FROM matches WHERE id = match_id) > NOW()
  )
  WITH CHECK (
    user_id = auth.uid()
    AND (SELECT vykop FROM matches WHERE id = match_id) > NOW()
  );

CREATE POLICY "bets_delete_admin"
  ON bets FOR DELETE TO authenticated
  USING (is_admin());

-- longterm_bets ------------------------------------------
-- INSERT/UPDATE: jen před prvním výkopem turnaje
-- Fallback timestamp: Mexiko vs JAR 11.6.2026 19:00 UTC (3 PM EDT)
ALTER TABLE longterm_bets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "lt_select"
  ON longterm_bets FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR is_admin());

CREATE POLICY "lt_insert"
  ON longterm_bets FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND NOW() < COALESCE(
      (SELECT MIN(vykop) FROM matches),
      '2026-06-11 19:00:00+00'::TIMESTAMPTZ
    )
  );

CREATE POLICY "lt_update"
  ON longterm_bets FOR UPDATE TO authenticated
  USING (
    user_id = auth.uid()
    AND NOW() < COALESCE(
      (SELECT MIN(vykop) FROM matches),
      '2026-06-11 19:00:00+00'::TIMESTAMPTZ
    )
  )
  WITH CHECK (
    user_id = auth.uid()
    AND NOW() < COALESCE(
      (SELECT MIN(vykop) FROM matches),
      '2026-06-11 19:00:00+00'::TIMESTAMPTZ
    )
  );

-- jackpot ------------------------------------------------
ALTER TABLE jackpot ENABLE ROW LEVEL SECURITY;

CREATE POLICY "jackpot_select"
  ON jackpot FOR SELECT TO authenticated USING (TRUE);

-- jackpot_payouts ----------------------------------------
ALTER TABLE jackpot_payouts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "jp_select"
  ON jackpot_payouts FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR is_admin());

-- tournament_state ---------------------------------------
ALTER TABLE tournament_state ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ts_select"
  ON tournament_state FOR SELECT TO authenticated USING (TRUE);

CREATE POLICY "ts_write"
  ON tournament_state FOR ALL TO authenticated
  USING (is_admin()) WITH CHECK (is_admin());


-- ============================================================
-- SEKCE 11: TRIGGER – auto-vytvoření profilu po registraci
-- ============================================================
-- Frontend volá:
--   supabase.auth.signUp({
--     email: `${prezdivka}@tipovacka.local`,
--     password,
--     options: { data: { jmeno, prijmeni, prezdivka, telefon } }
--   })
-- Trigger vytvoří řádek v profiles automaticky.

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO profiles (id, jmeno, prijmeni, prezdivka, telefon)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'jmeno',     ''),
    COALESCE(NEW.raw_user_meta_data->>'prijmeni',  ''),
    COALESCE(NEW.raw_user_meta_data->>'prezdivka', ''),
    COALESCE(NEW.raw_user_meta_data->>'telefon',   '')
  )
  ON CONFLICT (id) DO NOTHING;  -- pojistka pro edge case
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();


-- ============================================================
-- SEKCE 12: GRANTY
-- ============================================================

GRANT EXECUTE ON FUNCTION get_tip_price(faze_type)    TO authenticated;
GRANT EXECUTE ON FUNCTION is_admin()                   TO authenticated;
GRANT EXECUTE ON FUNCTION get_player_standings()       TO authenticated;
GRANT EXECUTE ON FUNCTION get_match_stats(BIGINT)      TO authenticated;
GRANT EXECUTE ON FUNCTION settle_match(BIGINT)         TO authenticated;
GRANT EXECUTE ON FUNCTION settle_longterm()            TO authenticated;
GRANT EXECUTE ON FUNCTION distribute_final_jackpot()   TO authenticated;


-- ============================================================
-- HOTOVO
-- Další krok: spustit 002_seed_teams.sql a 003_seed_matches.sql
-- ============================================================
